extends StaticBody2D

var is_pressed = false
var drop_height = 4 
@export var background_to_hide : Node2D  
@export var heart_to_show : Node2D      

@onready var sprite = $AnimatedSprite2D
@onready var main_collider = $CollisionShape2D 

func press_button():
	if is_pressed:
		return 
	
	is_pressed = true
	

	sprite.play("yes_down")
	main_collider.position.y += drop_height
	print("Button pressed")
	await get_tree().create_timer(1.0).timeout

	# hiding background
	if background_to_hide != null:
		background_to_hide.visible = false
		
	# showing heart 
	if heart_to_show != null:
		heart_to_show.visible = true
		


func _on_area_2d_body_entered(body):
	print("Touching the button, I'm ", body.name)
	if body.name == "Player" and not is_pressed:
		press_button()
