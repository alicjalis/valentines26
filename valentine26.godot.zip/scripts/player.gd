extends CharacterBody2D

const SPEED = 130.0
const JUMP_VELOCITY = -300.0
var gravity_scale = 1.0
@onready var animated_sprite = $AnimatedSprite2D

func _physics_process(delta: float) -> void:
	# gravity
	if not is_on_floor():
		velocity += get_gravity() * delta * gravity_scale

	# jump
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# moving
	var direction := Input.get_axis("move_left", "move_right")
	
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	

	if direction != 0:
		animated_sprite.flip_h = direction < 0

	if not is_on_floor():
		animated_sprite.play("jump")
		
	elif direction != 0:
		animated_sprite.play("walk_right")
		
	else:
		animated_sprite.play("idle")

func start_slow_fall():
	# slower fall
	gravity_scale = 0.4 
