extends Node2D

@export var player : CharacterBody2D
@export var button_yes : StaticBody2D
@export var button_no : StaticBody2D

func _ready():
	# hide
	if player:
		player.visible = false
		player.process_mode = Node.PROCESS_MODE_DISABLED
	
	if button_yes:
		button_yes.modulate.a = 0.0
		
	if button_no:
		button_no.modulate.a = 0.0
	
	start_intro_sequence()

func start_intro_sequence():
	await get_tree().create_timer(2.0).timeout
	
	var tween = create_tween()
		
	# Yes for 1 sec
	if button_yes:
		tween.tween_property(button_yes, "modulate:a", 1.0, 0.8)
	
	# 0.5 sec break
	tween.tween_interval(0.5)
	
	# No for 1 sec
	if button_no:
		tween.tween_property(button_no, "modulate:a", 1.0, 0.8)
		
	await tween.finished
	await get_tree().create_timer(2.0).timeout
	# Player shows
	if player:
		player.visible = true
		player.process_mode = Node.PROCESS_MODE_INHERIT
		
