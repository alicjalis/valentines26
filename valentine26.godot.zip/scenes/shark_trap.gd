extends Area2D

var jump_force = -900.0
var shark_gravity = 2000.0 

var velocity = Vector2.ZERO
var is_active = false

@onready var sprite = $AnimatedSprite2D

func _ready():
	sprite.play("bite")

func _physics_process(delta):
	if is_active:
		velocity.y += shark_gravity * delta
		
		position += velocity * delta
		if position.y > 2000:
			queue_free()

func start_attack():
	is_active = true
	velocity.y = jump_force
	print("attack!")

func _on_body_entered(body):
	if body is CharacterBody2D:
		body.queue_free()
		sprite.play("swim")
