extends StaticBody2D

@export var shark_to_trigger : Area2D 

var is_pressed = false
var drop_height = 4 

var player_ref = null

@onready var sprite = $AnimatedSprite2D
@onready var main_collider = $CollisionShape2D

func _ready():
	if sprite.sprite_frames.has_animation("no_up"):
		sprite.play("no_up")

func trigger_trap():
	if is_pressed: return
	is_pressed = true
	
	sprite.play("no_down")
	main_collider.position.y += drop_height
	print("Button pressed")
	sprite.play("no_broken")
	await get_tree().create_timer(1.0).timeout
	
	print("Button broken")
	if player_ref != null:
		player_ref.start_slow_fall()
	main_collider.set_deferred("disabled", true)
	await get_tree().create_timer(0.5).timeout

	if shark_to_trigger != null:
		shark_to_trigger.start_attack()
	else:
		print("Inspector")

func _on_area_2d_body_entered(body):
	if body is CharacterBody2D and not is_pressed:
		player_ref = body
		trigger_trap()
